# Licenses

Copyright 2026 Lior Isthmus.

The Python code is licensed under [Apache-2.0](LICENSE-APACHE-2.0).
Documentation, inputs, environment records, saved results, citation metadata
and checksums are licensed under [CC BY 4.0](LICENSE-CC-BY-4.0.md).

The Apache license text is included; the CC BY notice links its authoritative
legal terms. External SageMath, Python and Docker runtimes are not included.
